# Host this project on PythonAnywhere (free)

Your site will be at `https://YOUR_USERNAME.pythonanywhere.com` and works from any device, even when your computer is off.

## 1. Create an account
Sign up at https://www.pythonanywhere.com (choose the free "Beginner" plan). Your username becomes part of the link.

## 2. Upload the project
1. Open the **Files** tab → **Upload a file** → upload `FuelConsumptionAnalysis_Python_Login.zip`.
2. Open the **Consoles** tab → **Bash** and run:
   ```bash
   unzip FuelConsumptionAnalysis_Python_Login.zip
   ```
   You should now have a folder `/home/YOUR_USERNAME/FuelConsumptionAnalysis_Python`.

## 3. Install the packages
In the same Bash console:
```bash
mkvirtualenv fuelenv --python=python3.10
pip install -r FuelConsumptionAnalysis_Python/requirements.txt
```
(If `python3.10` is not available, use another version 3.10 or newer, for example `python3.11`.)

## 4. Create the web app
1. Open the **Web** tab → **Add a new web app** → **Next**.
2. Choose **Manual configuration** (not Flask) and the same Python version as above.
3. On the Web tab set:
   - **Source code:** `/home/YOUR_USERNAME/FuelConsumptionAnalysis_Python`
   - **Virtualenv:** `/home/YOUR_USERNAME/.virtualenvs/fuelenv`

## 5. Edit the WSGI file
On the Web tab click the **WSGI configuration file** link. Delete everything in it and paste:

```python
import sys, os

path = "/home/YOUR_USERNAME/FuelConsumptionAnalysis_Python"
if path not in sys.path:
    sys.path.insert(0, path)

# Change this to your own long random text. Keep it private.
os.environ["SECRET_KEY"] = "put-a-long-random-string-here"

from app import app as application
```
Replace `YOUR_USERNAME` and the secret text, then **Save**.

## 6. Start it
Click the green **Reload** button on the Web tab, then open `https://YOUR_USERNAME.pythonanywhere.com`. You will see the login page.

## Notes
- Free accounts must click **Run until 3 months from today** on the Web tab now and then, or the site is disabled.
- If something fails, check the **Error log** link on the Web tab.
- Data is stored in `fuel_records.db` inside the project folder on PythonAnywhere.
