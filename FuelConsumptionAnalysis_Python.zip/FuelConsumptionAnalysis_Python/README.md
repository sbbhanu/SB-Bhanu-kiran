# Fuel Consumption Analysis System — Python Website

A beginner-friendly full-stack Python website using Flask and SQLite.

## Features
- Sign up, log in and log out (passwords are hashed; each user sees only their own records).
- Add fuel records for vehicles.
- Calculate fuel cost (litres × price per litre).
- Calculate mileage (distance ÷ litres).
- Dashboard totals for fuel, cost, distance and average mileage.
- View and delete records.
- Dashboard refreshes automatically every 5 seconds.
- Data is saved in a local SQLite database.

## Requirements
- Python 3.10 or newer
- VS Code (recommended)

Check Python is installed:
```bash
python --version
```

## Run on Windows (VS Code)
1. Extract the ZIP file.
2. Open the `FuelConsumptionAnalysis_Python` folder in VS Code.
3. Select **Terminal → New Terminal**.
4. Run these commands one at a time:

```powershell
python -m venv venv
```

```powershell
venv\Scripts\activate
```

```powershell
pip install -r requirements.txt
```

```powershell
python app.py
```

5. Wait for Flask to show that it is running.
6. Open your browser at:

`http://127.0.0.1:5000`

Keep the terminal open while using the website. Press `Ctrl + C` to stop it.

If PowerShell blocks activation, use Command Prompt in VS Code or run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
venv\Scripts\activate
```

## Project folders
```text
FuelConsumptionAnalysis_Python/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   ├── index.html
│   ├── login.html
│   └── register.html
└── static/
    ├── style.css
    └── app.js
```

## About real-time operation
This is a local real-time-style dashboard. It refreshes from the saved database every 5 seconds. It does not automatically read fuel sensors or GPS from a real vehicle. That requires compatible vehicle hardware or a telematics API.

## Main formulas
- Total cost = fuel litres × price per litre
- Mileage = distance travelled in km ÷ fuel litres
- Average mileage = total distance ÷ total litres
