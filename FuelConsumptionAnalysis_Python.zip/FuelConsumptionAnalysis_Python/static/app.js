const form = document.getElementById('fuelForm');
const message = document.getElementById('message');
const money = n => '₹' + Number(n).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
const num = n => Number(n).toLocaleString('en-IN', {maximumFractionDigits:2});

async function refreshDashboard() {
  try {
    const [summaryResponse, recordsResponse] = await Promise.all([
      fetch('/api/dashboard'), fetch('/api/records')
    ]);
    if (summaryResponse.status === 401 || recordsResponse.status === 401) { window.location = '/login'; return; }
    if (!summaryResponse.ok || !recordsResponse.ok) throw new Error('Could not load data');
    const s = await summaryResponse.json();
    const records = await recordsResponse.json();
    document.getElementById('liters').textContent = num(s.liters) + ' L';
    document.getElementById('cost').textContent = money(s.cost);
    document.getElementById('distance').textContent = num(s.distance) + ' km';
    document.getElementById('mileage').textContent = num(s.mileage) + ' km/L';
    document.getElementById('count').textContent = records.length + (records.length === 1 ? ' record' : ' records');

    const body = document.getElementById('records');
    body.innerHTML = '';
    if (!records.length) {
      body.innerHTML = '<tr><td colspan="6" class="empty">No records yet. Add your first fuel entry.</td></tr>';
      return;
    }
    records.forEach(r => {
      const tr = document.createElement('tr');
      [r.vehicle, num(r.liters)+' L', num(r.distanceKm)+' km',
       num(r.mileage)+' km/L', money(r.totalCost)].forEach(value => {
        const td = document.createElement('td'); td.textContent = value; tr.appendChild(td);
      });
      const td = document.createElement('td');
      const del = document.createElement('button'); del.className = 'delete';
      del.textContent = 'Delete'; del.addEventListener('click', () => deleteRecord(r.id));
      td.appendChild(del); tr.appendChild(td); body.appendChild(tr);
    });
  } catch (error) {
    message.textContent = 'Cannot connect. Check that the Flask server is running.';
  }
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  message.textContent = 'Saving...';
  const data = Object.fromEntries(new FormData(form).entries());
  data.liters = Number(data.liters);
  data.pricePerLiter = Number(data.pricePerLiter);
  data.distanceKm = Number(data.distanceKm);
  try {
    const response = await fetch('/api/records', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not save record');
    form.reset();
    message.textContent = 'Fuel record saved successfully.';
    await refreshDashboard();
  } catch (error) { message.textContent = error.message; }
});

async function deleteRecord(id) {
  if (!confirm('Delete this fuel record?')) return;
  const response = await fetch('/api/records/' + id, {method:'DELETE'});
  if (response.ok) refreshDashboard();
  else message.textContent = 'Could not delete this record.';
}

refreshDashboard();
setInterval(refreshDashboard, 5000);
