import os
from functools import wraps
from flask import (Flask, render_template, request, jsonify,
                   session, redirect, url_for)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(BASE_DIR, "fuel_records.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
# Set a real secret in production: SECRET_KEY=some-long-random-string
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-only-change-me")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)


class FuelRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    vehicle = db.Column(db.String(100), nullable=False)
    liters = db.Column(db.Float, nullable=False)
    price_per_liter = db.Column(db.Float, nullable=False)
    distance_km = db.Column(db.Float, nullable=False)
    recorded_at = db.Column(db.DateTime, default=datetime.now)

    @property
    def total_cost(self):
        return round(self.liters * self.price_per_liter, 2)

    @property
    def mileage(self):
        return round(self.distance_km / self.liters, 2) if self.liters else 0


def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            session.clear()
            if request.path.startswith("/api/"):
                return jsonify({"error": "Please log in."}), 401
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapper


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("home"))
    error = None
    email = ""
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            session.clear()
            session["user_id"] = user.id
            return redirect(url_for("home"))
        error = "Invalid email or password."
    return render_template("login.html", error=error, email=email)


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user():
        return redirect(url_for("home"))
    error = None
    name = email = ""
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or "@" not in email:
            error = "Enter your name and a valid email."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        elif User.query.filter_by(email=email).first():
            error = "An account with this email already exists."
        else:
            user = User(name=name, email=email,
                        password_hash=generate_password_hash(password))
            db.session.add(user)
            db.session.commit()
            session.clear()
            session["user_id"] = user.id
            return redirect(url_for("home"))
    return render_template("register.html", error=error, name=name, email=email)


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def home():
    return render_template("index.html", user=current_user())


@app.get("/api/records")
@login_required
def get_records():
    records = FuelRecord.query.filter_by(user_id=session["user_id"]).order_by(FuelRecord.recorded_at.desc()).all()
    return jsonify([{
        "id": r.id,
        "vehicle": r.vehicle,
        "liters": r.liters,
        "pricePerLiter": r.price_per_liter,
        "distanceKm": r.distance_km,
        "totalCost": r.total_cost,
        "mileage": r.mileage,
        "recordedAt": r.recorded_at.strftime("%d %b %Y, %I:%M %p")
    } for r in records])


@app.get("/api/dashboard")
@login_required
def dashboard():
    records = FuelRecord.query.filter_by(user_id=session["user_id"]).all()
    liters = sum(r.liters for r in records)
    cost = sum(r.total_cost for r in records)
    distance = sum(r.distance_km for r in records)
    return jsonify({
        "entries": len(records),
        "liters": round(liters, 2),
        "cost": round(cost, 2),
        "distance": round(distance, 2),
        "mileage": round(distance / liters, 2) if liters else 0
    })


@app.post("/api/records")
@login_required
def add_record():
    data = request.get_json(silent=True) or {}
    try:
        vehicle = str(data.get("vehicle", "")).strip()
        liters = float(data.get("liters", 0))
        price = float(data.get("pricePerLiter", 0))
        distance = float(data.get("distanceKm", 0))
        if not vehicle or liters <= 0 or price <= 0 or distance < 0:
            return jsonify({"error": "Enter a vehicle, positive fuel and price, and non-negative distance."}), 400
        record = FuelRecord(user_id=session["user_id"], vehicle=vehicle, liters=liters,
                            price_per_liter=price, distance_km=distance)
        db.session.add(record)
        db.session.commit()
        return jsonify({"message": "Fuel record saved", "id": record.id}), 201
    except (TypeError, ValueError):
        return jsonify({"error": "Please enter valid numeric values."}), 400


@app.delete("/api/records/<int:record_id>")
@login_required
def delete_record(record_id):
    record = db.session.get(FuelRecord, record_id)
    if record is None or record.user_id != session["user_id"]:
        return jsonify({"error": "Record not found"}), 404
    db.session.delete(record)
    db.session.commit()
    return jsonify({"message": "Record deleted"})


with app.app_context():
    db.create_all()

if __name__ == "__main__":
    # Local use only. Set FLASK_DEBUG=1 to turn on debug mode while developing.
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1",
            host=os.environ.get("HOST", "127.0.0.1"), port=5000)
